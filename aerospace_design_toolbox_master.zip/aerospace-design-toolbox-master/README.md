mavl

A set of matlab functions for working with AVL, Xfoil, and other aerospace programs

For ease of use, put the *.m files somewhere convenient and then add the folder to matlab's path.  This way you won't have to worry about keeping them in your working directory.